-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-08-2025 a las 00:31:10
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `reservatec`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peticiones`
--

CREATE TABLE `peticiones` (
  `id_peticion` int(5) NOT NULL,
  `id_espacio` int(1) NOT NULL,
  `id_usuario` int(1) NOT NULL,
  `nombreEvento` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `peticion` text NOT NULL,
  `fecha_peticion` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado_peticion` enum('Aceptada','Rechazada','Procesando','') NOT NULL DEFAULT 'Procesando'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `peticiones`
--

INSERT INTO `peticiones` (`id_peticion`, `id_espacio`, `id_usuario`, `nombreEvento`, `fecha`, `hora_inicio`, `hora_fin`, `peticion`, `fecha_peticion`, `estado_peticion`) VALUES
(1, 2, 1, 'Curso Excel Avanzado', '2025-04-30', '13:08:00', '18:14:00', 'Curso impartido por el ingeniero Edgar Alatorre de excel avanzado, sin conocimiento previo.', '2025-04-11 05:07:32', 'Rechazada'),
(2, 1, 1, 'Conferencia PLC', '2025-05-22', '07:00:00', '15:00:00', 'Conferencia sobre PLC y su importancia en la industria.', '2025-04-11 06:48:29', 'Rechazada'),
(3, 5, 1, 'Expo Servicio Social', '2025-08-29', '10:30:00', '18:30:00', 'Feria del servicio social', '2025-04-11 06:49:53', 'Aceptada'),
(4, 2, 1, 'Certificacion Matlab', '2025-04-29', '15:00:00', '17:00:00', 'Curso Intensivo de MATLAB.', '2025-04-11 06:59:31', 'Rechazada'),
(5, 4, 1, 'Entrega de refrigerios', '2025-05-08', '16:30:00', '18:00:00', 'Entrega de refrigerio para alumnos del curso de programacion.', '2025-04-11 07:31:17', 'Procesando'),
(6, 2, 2, 'Demostracion de practica MATLAB.', '2025-04-29', '08:45:00', '10:45:00', 'Demostracion de practica MATLAB.', '2025-04-11 07:46:28', 'Procesando'),
(7, 1, 1, 'SITEC', '2025-04-30', '12:46:00', '16:47:00', 'evento', '2025-04-11 18:47:07', 'Procesando'),
(8, 1, 1, 'evento', '2025-04-30', '12:55:00', '13:53:00', 'evento', '2025-04-11 18:53:17', 'Procesando'),
(10, 5, 1, 'Torneo Smash Bros', '2025-05-30', '10:30:00', '12:30:00', 'Torneo de smash bros organizado por el CSC', '2025-05-26 18:15:25', 'Aceptada'),
(11, 5, 1, 'Semana de la Ciencia y la Tecnologia', '2025-06-05', '10:00:00', '13:00:00', 'Evento dedicado a exposiciones, talleres y conferencias sobre avances científicos, investigación e innovación tecnológica.', '2025-05-28 16:53:59', 'Rechazada'),
(12, 2, 1, 'Hackaton', '2025-06-09', '08:00:00', '12:00:00', 'Competencia intensiva de desarrollo de software o soluciones digitales para resolver retos propuestos por la industria o comunidad.', '2025-05-28 16:54:50', 'Aceptada'),
(13, 5, 1, 'Expo Emprende', '2025-06-18', '15:00:00', '19:30:00', 'Feria donde estudiantes exhiben sus ideas de negocio, startups o productos desarrollados en sus materias de emprendimiento o incubadoras.', '2025-05-28 16:59:02', 'Rechazada'),
(14, 5, 23, 'Feria Servicio Social', '2025-06-05', '08:00:00', '14:00:00', 'Exposicion de diferentes organizacion donde se podra realzar el sevicio.', '2025-05-28 17:02:35', 'Procesando'),
(15, 2, 23, 'Conferencia Networking', '2025-06-10', '13:00:00', '14:30:00', 'Conferencia de Networking impartida por el experto Eduardo Valdicvia.', '2025-05-28 17:04:32', 'Aceptada'),
(16, 2, 23, 'Convive con La IA', '2025-06-09', '11:00:00', '18:30:00', 'curso introductorio al taller convive con la IA impartida por el dr.Figueroa', '2025-05-28 17:06:46', 'Procesando');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `peticiones`
--
ALTER TABLE `peticiones`
  ADD PRIMARY KEY (`id_peticion`),
  ADD KEY `espacios_idespacio` (`id_espacio`),
  ADD KEY `usuarios_idusuario` (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `peticiones`
--
ALTER TABLE `peticiones`
  MODIFY `id_peticion` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `peticiones`
--
ALTER TABLE `peticiones`
  ADD CONSTRAINT `espacios_idespacio` FOREIGN KEY (`id_espacio`) REFERENCES `espacios` (`id_espacio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `usuarios_idusuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
